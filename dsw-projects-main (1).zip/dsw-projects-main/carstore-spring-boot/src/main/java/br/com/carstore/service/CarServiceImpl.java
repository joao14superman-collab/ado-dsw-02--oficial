package br.com.carstore.service;

import br.com.carstore.model.CarDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CarServiceImpl implements CarService  {

    private List<CarDTO> cars;

    public CarServiceImpl(){
        cars = new ArrayList<>();
    }

    @Override
    public List<CarDTO> findAll() {

        return this.cars;

    }

    @Override
    public void save(CarDTO carDTO) {

        cars.add(carDTO);

    }

    @Override
    public void deleteById(String id) {
        // Remove o carro pelo índice (id é o índice na lista)
        try {
            int index = Integer.parseInt(id);
            if (index >= 0 && index < cars.size()) {
                cars.remove(index);
            }
        } catch (NumberFormatException e) {
            // id inválido, não faz nada
        }
    }

    @Override
    public void update(String id, CarDTO carDTO) {
        // Atualiza o carro pelo índice (id é o índice na lista)
        try {
            int index = Integer.parseInt(id);
            if (index >= 0 && index < cars.size()) {
                cars.set(index, carDTO);
            }
        } catch (NumberFormatException e) {
            // id inválido, não faz nada
        }
    }

}
