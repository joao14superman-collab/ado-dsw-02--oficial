package br.com.carstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
